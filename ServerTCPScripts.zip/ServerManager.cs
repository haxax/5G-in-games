﻿using System;
using System.IO;
using System.Net;
using System.Net.Sockets;
using System.Runtime.CompilerServices;
using System.Text;
using System.Threading;

public class ServerManager
{
	public static ServerManager Instance { get; private set; }

	TcpListener listener;
	bool isRunning = true;
	List<(TcpClient, string)> connectedClients = new List<(TcpClient, string)>(); //string is the playerId
	public List<(TcpClient, string)> GetConnectedClients() { return connectedClients; }

	public void StartServer(int port = 5000)
	{
		Instance = this;

		IPAddress localAddress = IPAddress.Any;

		listener = new TcpListener(localAddress, port);
		listener.Start();
		Console.WriteLine($"Server ${(listener.LocalEndpoint as IPEndPoint).Address}({localAddress}) started on port {port}...");

		Thread acceptClientsThread = new Thread(AcceptClients);
		acceptClientsThread.Start();
	}

	private void AcceptClients()
	{
		while (isRunning)
		{
			TcpClient client = listener.AcceptTcpClient();
			lock (connectedClients) { connectedClients.Add((client, "")); }
			Console.WriteLine($"Client {(client.Client.RemoteEndPoint as IPEndPoint).Address} connected!");

			Thread clientThread = new Thread(HandleClient);
			clientThread.Start(client);
		}
	}

	private void HandleClient(object clientObj)
	{
		TcpClient client = (TcpClient)clientObj;
		NetworkStream stream = client.GetStream();
		string playerId = "";

		using (StreamReader reader = new StreamReader(stream, Encoding.UTF8))
		using (StreamWriter writer = new StreamWriter(stream, Encoding.UTF8) { AutoFlush = true })
		{
			while (client.Connected)
			{
				try
				{
					if (stream.DataAvailable && client.Available > 0)
					{
						// Read the incoming message
						byte[] buffer = new byte[client.Available];
						stream.Read(buffer, 0, buffer.Length);
						stream.Flush();

						// Process the received message
						IncomingMessages.ProcessMessage(client, playerId, buffer);

						if (playerId == "") { playerId = GetPlayerId(client); }
					}
				}
				catch (Exception e)
				{
					Console.WriteLine($"{(client.Client.RemoteEndPoint as IPEndPoint).Address} disconnected. {e}");
					break;
				}
			}
		}

		client.Close();
		Console.WriteLine($"Client connection closed.");
	}

	public void Broadcast(byte[] data)
	{
		lock (connectedClients)
		{
			foreach (var client in connectedClients)
			{
				if (client.Item1.Connected)
				{
					SendMessageToClient(client.Item1, data);
				}
				else
				{
					connectedClients.Remove(client);
				}
			}
		}
	}

	public void SendMessageToClient(TcpClient client, byte[] data)
	{
		try
		{
			NetworkStream stream = client.GetStream();
			stream.Write(data, 0, data.Length);
			stream.Flush();
		}
		catch (Exception ex)
		{
			Console.WriteLine($"Error sending message to client: {ex.Message}");
		}
	}




	public void SubmitPlayerId(TcpClient client, string playerId)
	{
		for (int i = connectedClients.Count - 1; i >= 0; i--)
		{
			if (connectedClients[i].Item1 == client)
			{
				connectedClients[i] = (client, playerId);
				break;
			}
		}
	}

	public string GetPlayerId(TcpClient client)
	{
		foreach (var c in connectedClients)
		{ if (c.Item1 == client) { return c.Item2; } }
		return "";
	}
}
