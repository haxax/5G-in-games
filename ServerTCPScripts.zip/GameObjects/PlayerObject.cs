﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net.Sockets;


public class PlayerObject : WorldObject
{
	public PlayerObject(string _playerId, int _objectId, LocationData _location) : base(1, _objectId, _location)
	{
		PlayerId = _playerId;
	}

	private string playerId;
	public string PlayerId { get => playerId; set => playerId = value; }

	private List<LocationData> locationHistory = new List<LocationData>();
	public List<LocationData> GetLocationHistory() => locationHistory;
	public TcpClient ActiveClient { get; set; }

	public void UpdateLocation()
	{
		LocationData newLocation = new LocationData(0, 0); //TODO get new location
		if (newLocation == locationHistory[locationHistory.Count - 1]) { return; }
		locationHistory.Add(newLocation);
	}

	public void ClearLocationHistory()
	{
		locationHistory.Clear();
	}




	public static PlayerObject CreateNewPlayer(string playerId)
	{
		return new PlayerObject(playerId, CreateNewObjectId(), new LocationData(0, 0));
	}
}