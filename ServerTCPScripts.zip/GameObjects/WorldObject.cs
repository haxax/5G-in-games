﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Numerics;


public class WorldObject
{
	private static int globalObjectIdCounter = 0;
	public static int CreateNewObjectId() { globalObjectIdCounter++; return globalObjectIdCounter; }
	public static int GetGlobalObjectCount() { return globalObjectIdCounter; }

	public WorldObject(byte _objectType, int _objectId, LocationData _location)
	{
		ObjectType = _objectType;
		ObjectId = _objectId;
		location = _location;
	}

	private byte objectType;
	public byte ObjectType { get => objectType; set => objectType = value; }

	private int objectId;
	public int ObjectId { get => objectId; set => objectId = value; }

	private LocationData location;
	public LocationData Location
	{
		get => location; set
		{
			if (value == location)
			{ return; }
			location = value;
			WorldManager.Instance.TryBroadcastNewLocation(this);
		}
	}
}

public class LocationData
{
	public LocationData(long _x, long _y)
	{
		X = _x; Y = _y;
	}

	private long x;
	public long X { get => x; set => x = value; }

	private long y;
	public long Y { get => y; set => y = value; }

	public static bool operator ==(LocationData a, LocationData b)
	{
		if (a.X == b.X && a.Y == b.Y) { return true; }
		return false;
	}
	public static bool operator !=(LocationData a, LocationData b)
	{
		if (a.X != b.X || a.Y != b.Y) { return true; }
		return false;
	}

	public int DistanceTo(LocationData other)
	{
		return (int)Math.Floor(Vector2.Distance(new Vector2(X, Y), new Vector2(other.X, other.Y)));
	}
}