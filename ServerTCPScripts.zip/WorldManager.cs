﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Numerics;
using System.Text;
using System.Threading.Tasks;


public class WorldManager
{
	public static WorldManager Instance { get; private set; }

	private List<WorldObject> worldObjects = new List<WorldObject>();
	private List<PlayerObject> playerObjects = new List<PlayerObject>();

	public const int RenderDistance = 10;

	public void CreateWorld()
	{
		Instance = this;
	}

	public PlayerObject RequestPlayer(string playerId)
	{
		foreach (PlayerObject p in playerObjects)
		{
			if (p.PlayerId == playerId)
			{
				return p;
			}
		}

		PlayerObject newPlayer = PlayerObject.CreateNewPlayer(playerId);
		worldObjects.Add(newPlayer);
		playerObjects.Add(newPlayer);
		return newPlayer;
	}

	public void TryBroadcastNewLocation(WorldObject worldObject)
	{
		foreach (PlayerObject p in playerObjects)
		{
			if (p.ActiveClient == null) { continue; }
			if (p.Location.DistanceTo(worldObject.Location) > RenderDistance) { continue; }
			OutgoingMessages.SendObjectLocationUpdate(p.ActiveClient, worldObject);
		}
	}

	public List<WorldObject> GetObjectsWithinPlayerRange(string playerId)
	{
		List<WorldObject> result = new List<WorldObject>();

		foreach (PlayerObject p in playerObjects)
		{
			if (p.PlayerId != playerId) { continue; }

			foreach (WorldObject w in worldObjects)
			{
				if (p.Location.DistanceTo(w.Location) > RenderDistance) { continue; }
				result.Add(w);
			}
			break;
		}

		return result;
	}
}