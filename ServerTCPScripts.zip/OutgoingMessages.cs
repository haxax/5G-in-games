﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net.Sockets;

public static class OutgoingMessages
{
	public static void SendMessage(TcpClient client, string msg)
	{
		Console.WriteLine($"Sending: {msg}");
		byte[] data = MsgSerialization.SerializeMessage(msg);
		TcpServer.ServerManager.SendMessageToClient(client, data);
	}
	public static void BroadcastMessage(string msg)
	{
		Console.WriteLine($"Broadcasting: {msg}");
		byte[] data = MsgSerialization.SerializeMessage(msg);
		TcpServer.ServerManager.Broadcast(data);
	}


	public static void SendObjectList(TcpClient client, List<WorldObject> objects)
	{
		Console.WriteLine($"Sending: object list with {objects.Count} objects");
		byte[] data = MsgSerialization.SerializeObjectList(objects);
		TcpServer.ServerManager.SendMessageToClient(client, data);
	}
	public static void BroadcastObjectList(List<WorldObject> objects)
	{
		Console.WriteLine($"Broadcasting: object list with {objects.Count} objects");
		byte[] data = MsgSerialization.SerializeObjectList(objects);
		TcpServer.ServerManager.Broadcast(data);
	}


	public static void SendObjectLocationUpdate(TcpClient client, WorldObject obj)
	{
		Console.WriteLine($"Sending: object {obj.ObjectId}");
		byte[] data = MsgSerialization.SerializeObjectLocationUpdate(obj);
		TcpServer.ServerManager.SendMessageToClient(client, data);
	}
	public static void BroadcastObjectLocationUpdate(WorldObject obj)
	{
		Console.WriteLine($"Broadcasting: object {obj.ObjectId}");
		byte[] data = MsgSerialization.SerializeObjectLocationUpdate(obj);
		TcpServer.ServerManager.Broadcast(data);
	}


	public static void SendObjectEventUpdate(TcpClient client, int objectId, byte eventType)
	{
		Console.WriteLine($"Sending: object event {eventType} to object {objectId}");
		byte[] data = MsgSerialization.SerializeObjectEventUpdate(objectId, eventType);
		TcpServer.ServerManager.SendMessageToClient(client, data);
	}
	public static void BroadcastObjectEventUpdate(int objectId, byte eventType)
	{
		Console.WriteLine($"Broadcasting: object event {eventType} to object {objectId}");
		byte[] data = MsgSerialization.SerializeObjectEventUpdate(objectId, eventType);
		TcpServer.ServerManager.Broadcast(data);
	}


	public static void SendPlayerLocationHistory(TcpClient client, List<LocationData> history)
	{
		Console.WriteLine($"Sending: location history with {history.Count} points");
		byte[] data = MsgSerialization.SerializePlayerLocationHistory(history);
		TcpServer.ServerManager.SendMessageToClient(client, data);
	}
	public static void BroadcastPlayerLocationHistory(List<LocationData> history)
	{
		Console.WriteLine($"Broadcasting: location history with {history.Count} points");
		byte[] data = MsgSerialization.SerializePlayerLocationHistory(history);
		TcpServer.ServerManager.Broadcast(data);
	}
}