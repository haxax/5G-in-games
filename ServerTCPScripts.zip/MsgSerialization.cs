﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

public static class MsgSerialization
{
	public static byte[] SerializeMessage(string msg)
	{
		using (MemoryStream ms = new MemoryStream())
		using (BinaryWriter writer = new BinaryWriter(ms))
		{
			writer.Write((byte)0);
			writer.Write(msg);

			return ms.ToArray();
		}
	}



	public static byte[] SerializeObjectList(List<WorldObject> objects)
	{
		using (MemoryStream ms = new MemoryStream())
		using (BinaryWriter writer = new BinaryWriter(ms))
		{
			writer.Write((byte)1); // Message type: 1 (object list)
			writer.Write(objects.Count); // Number of objects

			foreach (var obj in objects)
			{
				writer.Write(obj.ObjectType);
				writer.Write(obj.ObjectId);
				writer.Write(obj.Location.X);
				writer.Write(obj.Location.Y);
			}

			return ms.ToArray();
		}
	}



	public static byte[] SerializeObjectLocationUpdate(WorldObject obj)
	{
		using (MemoryStream ms = new MemoryStream())
		using (BinaryWriter writer = new BinaryWriter(ms))
		{
			writer.Write((byte)2); // Message type: 2 (location update)
			writer.Write(obj.ObjectType);
			writer.Write(obj.ObjectId);
			writer.Write(obj.Location.X);
			writer.Write(obj.Location.Y);

			return ms.ToArray();
		}
	}



	public static byte[] SerializeObjectEventUpdate(int objectId, byte eventType)
	{
		using (MemoryStream ms = new MemoryStream())
		using (BinaryWriter writer = new BinaryWriter(ms))
		{
			writer.Write((byte)3); // Message type: 3 (event update)
			writer.Write(objectId);
			writer.Write(eventType);

			return ms.ToArray();
		}
	}



	public static byte[] SerializePlayerLocationHistory(List<LocationData> history)
	{
		using (MemoryStream ms = new MemoryStream())
		using (BinaryWriter writer = new BinaryWriter(ms))
		{
			writer.Write((byte)4); // Message type: 4 (location history)
			writer.Write(history.Count); // Number of history entries

			foreach (var loc in history)
			{
				writer.Write(loc.X);
				writer.Write(loc.Y);
			}

			return ms.ToArray();
		}
	}
}