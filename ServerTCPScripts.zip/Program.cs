﻿using System;
using System.IO;
using System.Net;
using System.Net.Sockets;
using System.Runtime.CompilerServices;
using System.Text;
using System.Threading;

public class TcpServer
{
	private static ServerManager serverManager;
	public static ServerManager ServerManager => serverManager;
	private static WorldManager worldManager;
	public static WorldManager WorldManager => worldManager;

	static void Main(string[] args)
	{
		serverManager = new ServerManager();
		worldManager = new WorldManager();
		worldManager.CreateWorld();

		serverManager.StartServer();
	}
}