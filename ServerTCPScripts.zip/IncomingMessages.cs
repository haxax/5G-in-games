﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Net.Sockets;
using System.Text;
using System.Threading.Tasks;


static class IncomingMessages
{
	public static void ProcessMessage(TcpClient client, string playerId, byte[] data)
	{
		using (MemoryStream ms = new MemoryStream(data))
		using (BinaryReader reader = new BinaryReader(ms))
		{
			Console.WriteLine(reader.BaseStream.Length);
			byte messageType = reader.ReadByte(); // First byte: Message type

			switch (messageType)
			{
				case 0:
					Console.WriteLine($"Received: #{playerId} {reader.ReadString()}");
					break;
				case 1: // Submit playerId
					SubmitPlayerId(client, reader);
					break;

				case 2: // Request objects within range
					RequestObjectsWithinRange(client, playerId, reader);
					break;

				default:
					Console.WriteLine($"Received: Unknown message type {messageType} from #{playerId}");
					break;
			}
		}
	}

	private static void SubmitPlayerId(TcpClient client, BinaryReader reader)
	{
		string playerId = reader.ReadString();
		Console.WriteLine($"Received: #{playerId} submitting playerId");
		ServerManager.Instance.SubmitPlayerId(client, playerId);
		PlayerObject player = WorldManager.Instance.RequestPlayer(playerId);
		OutgoingMessages.SendObjectLocationUpdate(client, player);
	}

	private static void RequestObjectsWithinRange(TcpClient client, string playerId, BinaryReader reader)
	{
		Console.WriteLine($"Received: #{playerId} requesting objects");
		OutgoingMessages.SendObjectList(client, WorldManager.Instance.GetObjectsWithinPlayerRange(playerId));
	}
}