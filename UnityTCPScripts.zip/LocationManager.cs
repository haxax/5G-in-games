using UnityEngine;

public class LocationManager : MonoBehaviour
{
}
